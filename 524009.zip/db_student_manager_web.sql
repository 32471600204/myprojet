﻿# Host: localhost  (Version: 5.5.53-log)
# Date: 2022-05-24 00:08:42
# Generator: MySQL-Front 5.3  (Build 4.43)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "s_admin"
#

CREATE TABLE `s_admin` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `password` varchar(32) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT '1',
  `userName` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "s_admin"
#

INSERT INTO `s_admin` VALUES (1,'admin','1','admin');

#
# Structure for table "s_clazz"
#

CREATE TABLE `s_clazz` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Data for table "s_clazz"
#

INSERT INTO `s_clazz` VALUES (1,'软件一班'),(4,'数学一班'),(5,'计算机科学与技术一班');

#
# Structure for table "s_course"
#

CREATE TABLE `s_course` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `teacherid` varchar(255) NOT NULL DEFAULT '0',
  `teachername` varchar(255) DEFAULT NULL,
  `selectednum` varchar(255) NOT NULL DEFAULT '0',
  `maxnum` varchar(255) NOT NULL DEFAULT '50',
  `xuefen` varchar(255) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

#
# Data for table "s_course"
#

INSERT INTO `s_course` VALUES (1,'大学英语','9','张三','49','50','2'),(2,'大学数学','10','李四','50','50','2'),(3,'营养与健康','11','王五','8','50','1'),(25,'大学体育','6','赵六','6','6','2'),(26,'形势与政策','44','孙七','4','44','1'),(27,'艺术与审美','12','周八','3','11','1'),(30,'走进故宫','22','吴九','3','22','1');

#
# Structure for table "s_dingdan"
#

CREATE TABLE `s_dingdan` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(255) DEFAULT NULL,
  `studentname` varchar(255) DEFAULT NULL,
  `maxnum` int(11) DEFAULT '50',
  `xuefen` varchar(255) DEFAULT '2',
  `teachername` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `shuangsuoyin` (`coursename`,`studentname`) COMMENT '合并字段索引'
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8;

#
# Data for table "s_dingdan"
#


#
# Structure for table "s_student"
#

CREATE TABLE `s_student` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `class` int(11) NOT NULL DEFAULT '0',
  `password1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

#
# Data for table "s_student"
#

INSERT INTO `s_student` VALUES (1,'admin','admin',2,''),(2,'123','123',0,NULL),(3,'234','234',0,NULL),(4,'33','33',0,NULL),(5,'11','11',0,NULL),(6,'22','22',0,NULL),(7,'13','13',0,NULL);

#
# Structure for table "s_teacher"
#

CREATE TABLE `s_teacher` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL DEFAULT '1',
  `clazz_id` int(5) NOT NULL,
  `password1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

#
# Data for table "s_teacher"
#

INSERT INTO `s_teacher` VALUES (6,'赵六','1',0,NULL),(9,'张三','111',4,NULL),(10,'李四','111',4,NULL),(11,'王五','123456',5,NULL),(12,'周八','1',0,NULL),(22,'吴九','1',0,NULL),(44,'孙七','1',0,NULL);

#
# Structure for table "yun"
#

CREATE TABLE `yun` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `tupain` varchar(255) DEFAULT 'null',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

#
# Data for table "yun"
#

INSERT INTO `yun` VALUES (43,'QQ图片20220423002212.png');
