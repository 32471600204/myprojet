package com.mapper;

import com.dao.Yun;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface YunMapper {
    public List<Yun> selectAlltupian();
    public int inserttupian(Yun yun);
}
