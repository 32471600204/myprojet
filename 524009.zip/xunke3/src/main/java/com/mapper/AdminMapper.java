package com.mapper;

import com.dao.Admin;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper {
    public Admin selectAdminByuserName(String userName);

}
