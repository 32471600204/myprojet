package com.mapper;

import com.dao.Student;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StudentMapper {
    public List<Student> selectAlls_student();
    public Student selectStudentByname(String name);
public int inserts_student(Student student);
    public int updates_student(Student student);
    public int updatepassword(Student student);
}