package com.mapper;

import com.dao.Teacher;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface TeacherMapper {
    public List<Teacher> selectteacher();
}
