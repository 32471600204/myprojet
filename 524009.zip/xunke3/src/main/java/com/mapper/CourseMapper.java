package com.mapper;

import com.dao.Course;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CourseMapper {
    public List<Course> selectAlls_course();

    public  int inserts_course(Course course);
    public Course selects_course(String course);
    public int deletes_course(int name);
    public int updates_course(Course course);
    public int updateselectednum(Course course);
}
