package com.mapper;

import com.dao.Dingdan;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DingdanMapper {
    public List<Dingdan> selectAlls_dingdan();
    public  int inserts_dingdan(Dingdan dingdan);
    public Dingdan selects_dingdan(String dingdan);
    public Dingdan selectDingdanBystudentname(String studentname);
    public List<Dingdan> selectsdingdan(String studentname);
    public int deletesdingdan(int id);
}
