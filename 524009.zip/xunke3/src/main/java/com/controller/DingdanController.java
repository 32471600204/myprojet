package com.controller;

import com.dao.Dingdan;
import com.mapper.DingdanMapper;
import com.mapper.StudentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class DingdanController {
    @Autowired(required = false)
    private DingdanMapper dingdanMapper;



}

