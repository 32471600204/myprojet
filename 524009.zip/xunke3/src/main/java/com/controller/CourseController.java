package com.controller;

import com.dao.Course;
import com.mapper.CourseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
@Controller
public class CourseController {
    @Autowired(required = false)
    private CourseMapper courseMapper;
    //学生学生查看课程
//    public String y;
//    public void setY(String y){
//        this.y = y;
//    }

    @RequestMapping("/scourse")
    public String getcourse(Model model){
        
        List<Course> scourses = null;
        try{
            scourses=courseMapper.selectAlls_course();

        }catch (Exception e){
            System.out.println("数据库是空的");
        }
        model.addAttribute("scourses",scourses);


        System.out.println();

        return "scourse";
    }

    //管理员查看课程
    @RequestMapping("/menu")
    public String getacourse(Model model){
        List<Course> courses = null;
        try{
            courses=courseMapper.selectAlls_course();
        }catch (Exception e){
            System.out.println("数据库是空的");
        }
        model.addAttribute("courses",courses);
        return "menu";
    }


    //管理员添加课程
    @Autowired(required = false)
    @RequestMapping("/tianjia")
    public String tianjia(Course course, Model model, HttpSession session) {
        Course course1 = null;
        String name = course.getName();
        String teacherid = course.getTeacherid();
        String teachername = course.getTeachername();
        Integer selectednum = course.getSelectednum();
        Integer  maxnum= course.getMaxnum();
        String xuefen= course.getXuefen();
        System.out.println("a");
        System.out.println(course);
//        courseMapper.updateselectednum(course);
        System.out.println(name+","+teacherid+","+teachername+","+selectednum+","+maxnum+","+xuefen);
        if (name != null && teacherid != null && teachername != null
                && selectednum!= null && maxnum != null && xuefen != null ) {
            System.out.println(name+","+teacherid+","+teachername+","+selectednum+","+maxnum+","+xuefen);
            System.out.println(course);
            try {

                course1 = courseMapper.selects_course(name);

            } catch (Exception e) {

                System.out.println("该课程没有，可以添加");
            }
            if (course1 == null) {

                courseMapper.inserts_course(course);

                model.addAttribute("msg2", "课程添加成功");
            } else {
                model.addAttribute("msg2", "课程已存在");
            }
        }
        return "tianjia";
    }
    //管理员删除课程
    @GetMapping("/delete")
    public String delete(HttpServletRequest request) {
        Integer name = Integer.parseInt(request.getParameter("id"));
        System.out.println(name);
        try{
            courseMapper.deletes_course(name);
            return "redirect:menu";
        }catch (NullPointerException e){
            System.out.println("删除失败"+e);
        }
        return "menu";
    }
   // 管理员修改课程
    @RequestMapping("/update")
    public String updatekefang(Course course,Model model){

        try {

            courseMapper.updates_course(course);
            return "redirect:menu";
        }catch (Exception e){
            System.out.println("hello");
            model.addAttribute("msg","修改失败");
        }
        return "menu";
    }
}
