package com.controller;


import com.dao.Course;
import com.dao.Dingdan;
import com.dao.Student;
import com.mapper.CourseMapper;
import com.mapper.DingdanMapper;
import com.mapper.StudentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.applet.Applet;
import java.util.Calendar;
import java.util.List;

@Controller
public class StudentController {
    @Autowired(required = false)
    private StudentMapper studentMapper;
    @Autowired(required = false)
    private DingdanMapper dingdanMapper;
    @Autowired(required = false)
    private CourseMapper courseMapper;


    //   public void setY(String y) {
//       this.y = y;
//   }
//学生登录
    @RequestMapping("/slogin")
    public String slogin(Student student, Model model, HttpSession session,HttpServletRequest request) {

        String name = student.getName();
        String password = student.getPassword();
        model.addAttribute("currentYear", Calendar.getInstance().get(Calendar.YEAR));
        if (name != null && password != null) {
            try {
                Student student1 = studentMapper.selectStudentByname(name);
                if (student1.getPassword().equals(password)) {
                    session.setAttribute("sloginstudent", student1);




                    request.getSession().setAttribute("userName", student.getName());

//                    CourseController.setY(name);
                    return "redirect:scourse";
                } else {
                    model.addAttribute("smsg", "密码错误");
                }
            } catch (NullPointerException e) {
                model.addAttribute("smsg", "账号不存在");
            }
        }

        return "slogin";
    }


    //学生注册
    @RequestMapping("/zhuce")
    public String sign(Student student, Model model, HttpSession session) {

        Student student1 = null;


        String name = student.getName();
        String password = student.getPassword();
        String password1 = student.getPassword1();

        if (name != "" && password != "" && name != null && password != null) {
            if (!password.equals(password1)) {
                model.addAttribute("msg1", "前后密码不一致");
            } else {
                try {
                    student1 = studentMapper.selectStudentByname(name);
                } catch (NullPointerException e) {
                    System.out.println("数据库里没有，可以注册");
                }
                if (student1 == null) {
                    studentMapper.inserts_student(student);
                    System.out.println(student);
                    model.addAttribute("smsg", "注册成功");
                } else {
                    model.addAttribute("smsg", "用户名已存在");
                }
            }
        }
        return "zhuce";
    }

    //管理员查看学生
    @RequestMapping("/student")
    public String getstudent(Model model) {
        List<Student> students = null;
        try {
            students = studentMapper.selectAlls_student();

        } catch (Exception e) {
            System.out.println("数据库是空的");
        }
        model.addAttribute("students", students);
        return "student";
    }


    // 学生添加订单
    @RequestMapping("/xuanxiu")
    public String tianjiadingdan(Dingdan dingdan, RedirectAttributesModelMap model, HttpSession session, Course course) {
        //获取表单
        String coursename = dingdan.getCoursename();
        Integer maxnum=dingdan.getMaxnum();
        course.setName(coursename);
        //获取session内容
        Student student=(Student)session.getAttribute("sloginstudent");
        //获取当前账号的name
        String name = student.getName();
        dingdan.setStudentname(name);
        //获取当前课程已选人数
        Integer selectednum = course.getSelectednum();
        Integer selectednum2=selectednum+1;
        course.setSelectednum(selectednum2);
        if (selectednum2<=maxnum){
            if (coursename != null) {
                try {
                    dingdanMapper.inserts_dingdan(dingdan);
                    courseMapper.updateselectednum(course);
                    model.addFlashAttribute("msg2", "课程添加成功");
                    return "redirect:scourse";
                } catch (Exception e) {
                    System.out.println("你不能选择重复的课程");
                    model.addFlashAttribute("msg2", "你不能选择重复的课程");
                    return "redirect:scourse";
                }
            }
        }else {
            System.out.println("该课程人数已满");
            model.addFlashAttribute("msg2", "该课程人数已满，你不能选择该课程");
            return "redirect:scourse";
        }





        return "scourse";
    }

  //学生查看个人人信息
  @RequestMapping("/sxinxi")
  public String kanxinxi(Model model, HttpSession session) {
      Student students = null;
      Student student=(Student)session.getAttribute("sloginstudent");
      //获取当前账号的name
      String name = student.getName();
      try {
          students = studentMapper.selectStudentByname(name);

      } catch (Exception e) {
          System.out.println("数据库是空的");
      }
      model.addAttribute("students", students);
      return "sxinxi";
  }
    //学生查看已选课程
    @RequestMapping("/sdingdan")
    public String kandingdan(Model model,Dingdan dingdan,HttpSession session){
        //获取session内容
        Student student=(Student)session.getAttribute("sloginstudent");
        //获取当前账号的name
        String studentname = student.getName();
        dingdan.setStudentname(studentname);
        List<Dingdan> dingdans = null;
        try{
            dingdans=dingdanMapper.selectsdingdan(studentname);
        }catch (Exception e){
            System.out.println("数据库是空的");
        }
        model.addAttribute("dingdans",dingdans);
        return "sdingdan";
    }
    //学生退选课程
    @RequestMapping("/tuike")
    public String delete(Dingdan dingdan,Course course) {
        Integer id =dingdan.getId();
        String coursename=dingdan.getCoursename();
        try{
           dingdanMapper.deletesdingdan(id);
            course=courseMapper.selects_course(coursename);
            Integer selectednum = course.getSelectednum();
            Integer selectednum2=selectednum-1;
            course.setSelectednum(selectednum2);
            courseMapper.updateselectednum(course);

            return "redirect:sdingdan";
        }catch (NullPointerException e){
            System.out.println("删除失败"+e);
        }
        return "sdingdan";

    }
    //学生修改个人人信息

    @RequestMapping("/gai")
    public String gaixinxi(Student student,Model model){

Integer id=student.getId();


        student.setPassword(student.getPassword());

        try {
            System.out.println("aa");
studentMapper.updatepassword(student);
            System.out.println("aa");
            return "redirect:sxinxi";
        }catch (Exception e){
            System.out.println("hello");
            model.addAttribute("msg","修改失败");
        }
        return "sxinxi";
    }
    @RequestMapping("/tuichu")
    public String tuichu(Student student, Model model, HttpSession session,HttpServletRequest request) {
        request.getSession().setAttribute("userName", null);
        return "slogin";
    }
}