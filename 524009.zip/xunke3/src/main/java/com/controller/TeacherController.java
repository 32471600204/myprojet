package com.controller;


import com.dao.Teacher;
import com.mapper.TeacherMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class TeacherController {
    @Autowired(required = false)
    private TeacherMapper teacherMapper;
    @RequestMapping("/teacher")
    public String getteacher(Model model){
       List<Teacher> teachers = null;
       try{
           teachers = teacherMapper.selectteacher();
       }catch (Exception e){
           System.out.println(e);
       }
       model.addAttribute("teachers",teachers);
       return "teacher";
   }

}
