package com.controller;

import com.dao.Yun;
import com.mapper.YunMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@Controller
public class FileController {

    // 向文件上传页面跳转
    @GetMapping("/toUpload")
    public String toUpload(){
        return "upload";
    }
    // 文件上传管理
    @Autowired(required = false)
    private YunMapper yunMapper;
    @PostMapping("/uploadFile")
    public String uploadFile(MultipartFile[] fileUpload, Model model, Yun yun) {
        List<Yun> yuns= null;
        try {
            yuns = yunMapper.selectAlltupian();

        } catch (Exception e) {
            System.out.println("数据库是空的");
        }
        model.addAttribute("yuns", yuns);
        // 默认文件上传成功，并返回状态信息
        model.addAttribute("uploadStatus", "上传成功！");
        for (MultipartFile file : fileUpload) {
            // 获取文件名以及后缀名
            String fileName = file.getOriginalFilename();
            String tupian;
            // 重新生成文件名（根据具体情况生成对应文件名）
            //fileName = UUID.randomUUID()+"_"+fileName;
            // 指定上传文件本地存储目录，不存在则需要提前创建
            String dirPath = "E:/ideake/java/xunke3/src/main/resources/static/img/";
            File filePath = new File(dirPath);
            if(!filePath.exists()){
                filePath.mkdirs();

            }
            try {
                file.transferTo(new File(dirPath+fileName));

                tupian=fileName;

                System.out.println(tupian);
                yun.setTupain(tupian);
                System.out.println(yun);
                yunMapper.inserttupian(yun);

            } catch (Exception e) {
                e.printStackTrace();
                // 上传失败，返回失败信息
                model.addAttribute("uploadStatus","上传失败： "+e.getMessage());
            }
        }
        //        携带上传状态信息回调到文件上传页面
//        List<Yun> yuns= null;
//        try {
//            yuns = yunMapper.selectAlltupian();
//
//        } catch (Exception e) {
//            System.out.println("数据库是空的");
//        }
//        model.addAttribute("yuns", yuns);
//        return "redirect:upload";
        return "upload";
    }
}




