package com.controller;

import com.dao.Admin;
import com.dao.Teacher;
import com.mapper.AdminMapper;
import com.mapper.TeacherMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
//登录
public class AdminController {
    @Autowired(required = false)
    private AdminMapper adminMapper;

    @RequestMapping("/login")
    public String login(Admin admin, Model model, HttpSession session) {
        String userName = admin.getUserName();
        String password = admin.getPassword();
        if(userName != null && password != null){
            try {
                Admin admin1 = adminMapper.selectAdminByuserName(userName);
                if (admin1.getPassword().equals(password)) {
                    session.setAttribute("loginadmin",admin1);
                    return "redirect:menu";
                } else {
                    model.addAttribute("msg", "密码错误");
                }
            } catch (NullPointerException e) {
                model.addAttribute("msg", "账号不存在");
            }
        }
        return "login";
    }

}