package com.controller;
 import org.springframework.stereotype.Controller;
 import org.springframework.ui.Model;
  import org.springframework.web.bind.annotation.GetMapping;
 import java.util.Calendar;
  @Controller
  public class LoginController {
  /**
   * 获取并封装当前年份，跳转到登录页 login.html
   */
         @GetMapping("/toLoginPage")
  public String toLoginPage(Model model){
         model.addAttribute("currentYear", Calendar.getInstance().get(Calendar.YEAR));
         return "slogin";
         }
  }

