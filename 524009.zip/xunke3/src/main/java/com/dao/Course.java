package com.dao;

public class Course {
    private int id;
    private String name;
    private String teacherid;
    private String teachername;
    private int selectednum;
    private int maxnum;
    private String xuefen;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(String teacherid) {
        this.teacherid = teacherid;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public int getSelectednum() {
        return selectednum;
    }

    public void setSelectednum(int selectednum) {
        this.selectednum = selectednum;
    }

    public int getMaxnum() {
        return maxnum;
    }

    public void setMaxnum(int maxnum) {
        this.maxnum = maxnum;
    }

    public String getXuefen() {
        return xuefen;
    }

    public void setXuefen(String xuefen) {
        this.xuefen = xuefen;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", teacherid='" + teacherid + '\'' +
                ", teachername='" + teachername + '\'' +
                ", selectednum=" + selectednum +
                ", maxnum=" + maxnum +
                ", xuefen='" + xuefen + '\'' +
                '}';
    }
}

