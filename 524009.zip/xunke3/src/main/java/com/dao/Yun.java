package com.dao;

public class Yun {
Integer id;
    String tupain;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTupain() {
        return tupain;
    }

    public void setTupain(String tupain) {
        this.tupain = tupain;
    }

    @Override
    public String toString() {
        return "Yun{" +
                "id=" + id +
                ", tupain='" + tupain + '\'' +
                '}';
    }
}
