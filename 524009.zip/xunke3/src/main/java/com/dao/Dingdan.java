package com.dao;

public class Dingdan {
    private int id;
    private String coursename;
    private String studentname;
    private int maxnum;
    private String xuefen;
    private String teachername;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getStudentname() {
        return studentname;
    }

    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

    public int getMaxnum() {
        return maxnum;
    }

    public void setMaxnum(int maxnum) {
        this.maxnum = maxnum;
    }

    public String getXuefen() {
        return xuefen;
    }

    public void setXuefen(String xuefen) {
        this.xuefen = xuefen;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    @Override
    public String toString() {
        return "Dingdan{" +
                "id=" + id +
                ", coursename='" + coursename + '\'' +
                ", studentname='" + studentname + '\'' +
                ", maxnum=" + maxnum +
                ", xuefen='" + xuefen + '\'' +
                ", teachername='" + teachername + '\'' +
                '}';
    }
}
